# 运行之前请把.txt文件全部删除
# Please delete all .txt files before running this program to ensure no potential risk

from sklearn.svm import SVC
import os
import numpy as np

class SVC_cla(SVC):
    def __init__(self,kernel='linear',C=1e5,degree=2,gamma=0.5,decision_function_shape = 'ovo'):
        self.decision_function_shape = decision_function_shape
        super().__init__(kernel=kernel,C=C,gamma=gamma,degree=degree)

    # input: y; output: y_split
    # function: Divide each class separately from the other classes,
    #           labeled 1 for that class and -1 for the others(即手动实现ovr)
    def Y_split(self, y):
        y_split = {}
        self.Classes = set(y)
        for cla in self.Classes:
            y_split[cla] = [1 if c == cla else -1 for c in y]
        return y_split

    # To judge whether to use 'ovo' or 'ovr'
    def fit(self,X,y):
        if(self.decision_function_shape == 'ovo'):
            super().fit(X,y)
        else:
            self.FIT(X,y)

    def FIT(self,X,y):
        y_split = self.Y_split(y)
        self.X_train = X
        self.y_split = y_split
        Predict = {}
        slack_variable = {}
        w = []
        b = []
        sv = []
        for c, y_splited in y_split.items():
            super().fit(X,y_splited)
            if(self.kernel == 'linear'):
                w.append(self.coef_[0])
            if(self.kernel != 'rbf' and self.kernel != 'sigmoid'):
                b.append(self.intercept_[0])
            else:
                b.append(0)
            sv.append(self.support_)
            Predict[c] = self.decision_function(X)
            y_temp = y_split[c]*self.decision_function(X)
            slack_variable[c] = [1 - y_t if abs(y_t)<=1 else 0.0 for y_t in y_temp]
        Y_predict = np.array(list(map(np.argmax, zip(*Predict.values()))))
        loss = 0
        for y_pre,y_gt in zip(Y_predict,y):
            if(y_pre != y_gt):
                loss += 1/len(Y_predict)
        results = {
            'train_loss': loss,
            'w': w,
            'b': b,
            'support vector': sv,
            'slack_variable': slack_variable,
        }
        self.output = results

    def predict(self, X,y):
        if(self.decision_function_shape == 'ovo'):
            super().predict(X)
        else:
            self.Predict(X,y)

    def Predict(self,X,y):
        Predict = {}
        for cla in self.Classes:
            super().fit(X=self.X_train,y=self.y_split[cla])
            Predict[cla] = self.decision_function(X)
        Y_predict = np.array(list(map(np.argmax, zip(*Predict.values()))))
        loss = 0
        for y_pre,y_gt in zip(Y_predict,y):
            if(y_pre != y_gt):
                loss += 1/len(Y_predict)
        self.output['test_loss'] = loss

# read file
f_train = open("train.txt", "r")
datas_train = [line for line in f_train]
y_train = [int(data.split()[0]) for data in datas_train]
X_train = [list(map(float,data.split()[1:5])) for data in datas_train]

f_test = open("test.txt", "r")
datas_test = [line for line in f_test]
y_test = [int(data.split()[0]) for data in datas_test]
X_test = [list(map(float,data.split()[1:5])) for data in datas_test]

# Question 1
svc = SVC_cla(kernel='linear',C=1e5,decision_function_shape='ovr')
svc.fit(X_train,y_train)
svc.predict(X_test,y_test)
outputs = svc.output

error_train = outputs['train_loss']
error_test = outputs['test_loss']

support_vectors_indexs = outputs['support vector']

W = outputs['w']
B = outputs['b']

with open("SVM_linear.txt", "w") as f:
    f.write("${"+f"{error_train}"+"}\n")
    f.write("${" + f"{error_test}" + "}\n")
    for i in range(3):
        w_str = ",".join(list(map(str, W[i])))
        b = B[i]
        sv = support_vectors_indexs[i]
        sv_str = ",".join(list(map(str, sv)))
        f.write("${" + f"{w_str}" + "}\n")
        f.write("${" + f"{b}" + "}\n")
        f.write("${" + f"{sv_str}" + "}\n")
    f.close()


# Question 2
for t in range(1,11):
    C = 0.1*t
    svc = SVC_cla(kernel='linear', C=C, decision_function_shape='ovr')
    svc.fit(X_train, y_train)
    svc.predict(X_test, y_test)
    outputs = svc.output

    error_train = outputs['train_loss']
    error_test = outputs['test_loss']

    support_vectors_indexs = outputs['support vector']
    slack_variable = outputs['slack_variable']

    W = outputs['w']
    B = outputs['b']

    with open("SVM_slack.txt", "a") as f:
        f.write("C = " + f"{C}" + "\n")
        f.write("${" + f"{error_train}" + "}\n")
        f.write("${" + f"{error_test}" + "}\n")
        for i in range(3):
            w_str = ",".join(list(map(str, W[i])))
            b = B[i]
            sv = support_vectors_indexs[i]
            sv_str = ",".join(list(map(str, sv)))
            f.write("${" + f"{w_str}" + "}\n")
            f.write("${" + f"{b}" + "}\n")
            f.write("${" + f"{sv_str}" + "}\n")
            f.write("${" + f"{slack_variable[i]}" + "}\n")
        f.write("\n")
        f.write("----------------------------------------------------------------")
        f.write("\n")



# Question 3
def svc_with_different_kernel_function(kernel_function ="linear",gamma=0.5,C=1,save_path='',save_filename=''):
    output_file = os.path.join(save_path,save_filename)
    if kernel_function in ["poly2","poly3"]:
        if "poly" in kernel_function:
            degree = int(kernel_function[-1])
            kernel_function = kernel_function[:-1]
            svc = SVC_cla(kernel=kernel_function, C=C,degree=degree, gamma='auto', decision_function_shape='ovr')
        else:
            raise ValueError("kernel_function ineffective")
    else:
        svc = SVC_cla(kernel=kernel_function, C=C, gamma=gamma,decision_function_shape='ovr')

    svc.fit(X_train, y_train)
    svc.predict(X_test, y_test)

    outputs = svc.output

    error_train = outputs['train_loss']
    error_test = outputs['test_loss']

    support_vectors_indexs = outputs['support vector']

    B = outputs['b']
    with open(output_file, "w") as f:
        f.write("${" + f"{error_train}" + "}\n")
        f.write("${" + f"{error_test}" + "}\n")
        for i in range(3):
            b = B[i]
            sv = support_vectors_indexs[i]
            sv_str = ",".join(list(map(str, sv)))
            f.write("${" + f"{b}" + "}\n")
            f.write("${" + f"{sv_str}" + "}\n")
        f.close()


C = 1
Gamma = 0.5
kernel_functions = ["poly2","poly3","rbf","sigmoid"]
save_filenames = ["SVM_poly2.txt","SVM_poly3.txt","SVM_rbf.txt","SVM_sigmoid.txt"]
for kf,sf in zip(kernel_functions,save_filenames):
    svc_with_different_kernel_function(kernel_function=kf,
                                       gamma=Gamma,
                                       C=C,
                                       save_filename=sf
                                       )