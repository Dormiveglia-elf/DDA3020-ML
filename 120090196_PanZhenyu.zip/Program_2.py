import numpy as np
import pandas as pd
# to encode categorical features as one-hot numeric array
from sklearn.preprocessing import OneHotEncoder
# scientific computing library
from scipy.special import softmax
from sklearn.model_selection import train_test_split
# accuracy function
from sklearn.metrics import accuracy_score
# instantiate the encoder
onehot_encoder = OneHotEncoder(sparse=False)

# gradient
def gradient(X, Y, W, u):
	# matrix multiplication
	M = -X @ W
	# P is the probability, this process is forward propagation
	P = softmax(M, axis=1)
	# number of rows of X denoted as X
	N = X.shape[0]
	# 1 / N * (X.T @ (Y - P)) is gradient of log-likelyhood with respect to w;
	# 2 * mu * W is l2 regularization gradient
	re = 1 / N * (X.T @ (Y - P)) + 2 * u * W
	return re

# gradient descent, learning rate(alpha) = 0.1
def gradient_descent(X, Y, iteration=1000, alpha=0.1, u=0.01):
	# transform Y to one-hot numeric array
	Y_onehot = onehot_encoder.fit_transform(Y)
	# initialize the W, the number of rows/columns equal to columns of X/Y;
	W = np.zeros((X.shape[1], Y_onehot.shape[1]))

	for step in range(iteration):
		# the step size is the learning rate, the direction is the gradient
		W -= alpha * gradient(X, Y_onehot, W, u)
	return W


# Classifier using gradient descent algorithm
class Classifier:
	# train the model
	def train(self, X, Y):
		# invoke the gradient_descent function
		self.W = gradient_descent(X, Y)

	# predict
	def predict(self, X):
		# matrix multiplication
		M = -X @ self.W
		# convert the scalar value to probability value using softmax
		P = softmax(M, axis=1)
		# return the max probability value
		return np.argmax(P, axis=1)

# Classifier without using gradient descent
class Classifier_without_gd:
	def train(self, X, Y):
		Y_onehot = onehot_encoder.fit_transform(Y.reshape(-1, 1))
		xTx = np.matmul(X.T, X)
		self.w = np.matmul(np.matmul(np.linalg.inv(xTx), X.T), Y_onehot);

	def predict(self, X):
		y_pred = np.matmul(X, self.w)
		return np.argmax(y_pred, axis=1)

# load the iris dataset
df_iris = pd.read_excel("Classification iris.xlsx", header=None)

lm = {
	'Iris-setosa': 0,
	'Iris-versicolor': 1,
	'Iris-virginica': 2
}

# convert the string to the corresponding label in the lm dictionary using function apply
df_iris[4] = df_iris[4].apply(lambda x: lm[x])

# first four attributes denoted as ndarray X
X = df_iris.iloc[:, :-1].values
# label denoted as ndarray Y
Y = df_iris.iloc[:, -1:].values

# repeat 10 times
for i in range(10):
	# split the sample, 80% for training, 20% for testing
	X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

	model = Classifier()
	# model = Classifier_without_gd()

	# train the model
	model.train(X_train, Y_train)
	# the classification error rate = 1 - accuracy_score
	train_error = 1-accuracy_score(Y_train, model.predict(X_train))
	test_error = 1-accuracy_score(Y_test, model.predict(X_test))
	# output
	print(f'i = {i + 1}')
	print(f'train error = {train_error}')
	print(f'test error = {test_error}')
	print('==' * 50)