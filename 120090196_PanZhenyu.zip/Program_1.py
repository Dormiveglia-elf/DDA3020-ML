import pandas as pd

# load the data
df_reg = pd.read_excel('Regression.xlsx')
# perform data preprocessing and drop NA value
df_reg = df_reg.dropna()

# attributes 3-23 (start at index 0, so 2: 23)
X = df_reg.iloc[:, 2: 23].values
# attribute Next_Tmax
y1 = df_reg.iloc[:, [23]].values
# attribute Next_Tmin
y2 = df_reg.iloc[:, [24]].values

# invoke numpy library
import numpy as np
# to calculate the mean_squared_error
from sklearn import metrics
# to distinguish between traing and testing data
from sklearn.model_selection import train_test_split
# invoke data preprocessing
from sklearn.preprocessing import StandardScaler

# Regression Class
class Regression:
    # Constructor of the class
    def __init__(self, learning_rate, iteration):
        # m is sample，also the number of rows
        self.m = None
        # n is feature, also the number of columns
        self.n = None
        # w is weight
        self.w = None
        # bias
        self.b = None
        # learning rate
        self.lr = learning_rate
        # iteration times, in linear regression, usually 100 -150 is enough
        self.it = iteration

    # mean square error
    def cost_function(self, y, y_pred):
        return (1 / (2 * self.m)) * np.sum(np.square(y_pred - y))

    # calculate the prediction using linear regression
    def hypothesis(self, weights, bias, X):
        return np.dot(X, weights)

    # training process
    def train(self, X, y):
        # insert all one in column 0 of X，equal to b+wx
        X = np.insert(X, 0, 1, axis=1)
        # judge whether the prediction dimenssion is 2
        assert len(y.shape) == 2
        # m record the rows
        self.m = X.shape[0]
        # n record the columns
        self.n = X.shape[1]
        # initialize weight w
        self.w = np.zeros((self.n, 1))
        # initialize bias b
        self.b = 0
        # iteration loop
        for it in range(1, self.it + 1):
            # calculate the current prediction value
            y_pred = self.hypothesis(self.w, self.b, X)
            # calculate the current cost
            cost = self.cost_function(y, y_pred)
            # gradient descent algorithm
            dw = (1 / self.m) * np.dot(X.T, (y_pred - y))
            # gradient descent alogorithm
            self.w = self.w - self.lr * dw
            # observe the cost every 10 iterations
            # if it % 50 == 0:
            #     print(f"iter = {it}; cost = {cost}")

    # prediction process
    def predict(self, test_X):
        # insert all one in column 0 of X，equal to b+wx
        test_X = np.insert(test_X, 0, 1, axis=1)
        # calculate with updated w
        y_pred = self.hypothesis(self.w, self.b, test_X)
        return y_pred

# repeat the splitting, training, and testing for 10 times
for i in range(10):
    # 80% for training data, 20% for tesing data
    X_train, X_test, y1_train, y1_test, y2_train, y2_test = train_test_split(X, y1, y2, test_size=0.2)
    # instantiate standard object to scale features later
    scaler = StandardScaler()
    # standardize training and testing data
    X_train_sca = scaler.fit_transform(X_train)
    X_test_sca = scaler.transform(X_test)
    # instantiate Regression object
    linear_reg = Regression(learning_rate=0.05, iteration=150)
    # invoke training method
    linear_reg.train(X_train_sca, y1_train)
    # invoke prediction method
    y1_test_pred = linear_reg.predict(X_test_sca)
    y1_train_pred = linear_reg.predict(X_train_sca)
    # calculate the mean squared error of first training and testing data
    mse1_test = metrics.mean_squared_error(y1_test, y1_test_pred, squared=True)
    mse1_train = metrics.mean_squared_error(y1_train, y1_train_pred, squared=True)

    # similar as above
    linear_reg.train(X_train_sca, y2_train)
    y2_train_pred = linear_reg.predict(X_train_sca)
    y2_test_pred = linear_reg.predict(X_test_sca)
    mse2_train = metrics.mean_squared_error(y2_train, y2_train_pred, squared=True)
    mse2_test = metrics.mean_squared_error(y2_test, y2_test_pred, squared=True)

    # calculate the RMSE for two-dimensional vector
    RMSE_train = np.sqrt((mse1_train + mse2_train)/2)
    RMSE_test = np.sqrt((mse1_test + mse2_test)/2)

    # print out the result
    print(f'i = {i + 1}')
    print(f"RMSE_TRAIN = {RMSE_train}")
    print(f"RMSE_TEST = {RMSE_test}")
    print('==' * 50)
